import PogObject from "../../PogData"

export class idkwhatimdoing {
    static data = new PogObject("Hideout", {
        firstload: true
    }, "data/.data.json")
}